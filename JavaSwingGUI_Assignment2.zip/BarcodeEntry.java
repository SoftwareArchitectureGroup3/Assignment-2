package SwingGUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class BarcodeEntry implements ActionListener {

    // Creating a hashmap that will associate a particular barcode to a product
    //For testing we have stored 5 products ( Banana, Apple , Oranges, Watermelon, Chips )
    private HashMap<String, String> products = new HashMap<String, String>();
    private static JLabel label;
    private static JTextField barcode;
    private static JButton btn1;
    private static JLabel label2;
    private static JButton btn2;


    public BarcodeEntry(){

        JFrame frame = new JFrame("Barcode");
        JPanel panel = new JPanel();
        frame.setSize(400,250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.add(panel);
        panel.setLayout(null);

        label = new JLabel("Barcode");
        label.setBounds(10, 20, 200,25);
        panel.add(label);

        barcode = new JTextField(20);
        barcode.setBounds(100,20,165,25);
        panel.add(barcode);

        btn1 = new JButton("SEARCH PRODUCT");
        btn1.setBounds(80,80,200,25);
        btn1.addActionListener(this);
        panel.add(btn1);

        label2 = new JLabel(" ");
        label2.setBounds(10, 120, 350,25);
        panel.add(label2);

        btn2 = new JButton("PAYMENT");
        btn2.setBounds(80,180,200,25);
        btn2.addActionListener(
                new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        new PaymentOption();
                    }
                }
        );
        panel.add(btn2);

        // Adding 5 items to the hash map
        products.put("001","Banana");
        products.put("002","Apple");
        products.put("003","Orange");
        products.put("004","Watermelon");
        products.put("005","Chips");

        frame.setVisible(true);



    }

    public static void main(String[] args) {
        new BarcodeEntry();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       String code = barcode.getText();

        for(String key: products.keySet()) {
            if (code.equals(key)){
                label2.setText("The product you are looking for is : "+" "+products.get(key));

                break;
            }
            else {
                label2.setText("UNKNOWN PRODUCT");
            }
        }

    }
}
