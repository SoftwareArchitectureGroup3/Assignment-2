package SwingGUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PaymentOption implements ActionListener {
    private static JButton btn;
    private static JButton btn1;
    private static JLabel l1;
    private static JLabel success;

    public PaymentOption(){
        JPanel panel = new JPanel();
        JFrame frame = new JFrame("Payment Option");
        frame.setSize(550,350);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.add(panel);
        panel.setLayout(null);

        l1=new JLabel("PLEASE SELECT ANY ONE OF THE PAYMENT OPTIONS");
        l1.setBounds(100,100,500,25);
        panel.add(l1);

        success = new JLabel("");
        success.setBounds(90,220,200,25);
        panel.add(success);

        btn = new JButton("CASH");
        btn.setBounds(80,200,400,25);
        btn.addActionListener(
                new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        success.setText("Print receipt");
                    }
                }
        );
        panel.add(btn);

        btn1 = new JButton("CREDIT/DEBIT CARD");
        btn1.setBounds(80,250,400,25);
        btn1.addActionListener(this);
        panel.add(btn1);

        frame.setVisible(true);

    }

    public static void main(String[] args) {
        new PaymentOption();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        new PaymentSystem();
    }
}
