package SwingGUI;

import javax.swing.*;  //importing swing package
import javax.swing.*;  //importing swing package
import java.awt.*;     //importing awt package
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class First implements ActionListener
{

    JButton btn;
    JLabel label;
    public First() {
        JPanel panel = new JPanel();
        JFrame frame = new JFrame("Cash Register");
        frame.setSize(400,200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.add(panel);

        panel.setLayout(null);

        label=new JLabel("WELCOME USER");
        label.setBounds(10,20,200,25);
        panel.add(label);

        btn=new JButton("CREATE NEW SESSION");
        btn.setBounds(5,80,400,25);
        btn.addActionListener(this);
        panel.add(btn);




        frame.setVisible(true);
    }
    public static void main(String[] args)
    {
        new First();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        new BarcodeEntry();
    }
}
