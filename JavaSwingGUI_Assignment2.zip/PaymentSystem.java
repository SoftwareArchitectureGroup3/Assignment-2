package SwingGUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PaymentSystem implements ActionListener {
    private static JLabel label;
    private static JLabel label2;
    private static JLabel label3;
    private static JLabel success;
    private static JTextField cardDetails;
    private static JTextField cardName;
    private static JPasswordField CVV;
    private static JButton btn;

    public PaymentSystem() {

        JPanel panel = new JPanel();
        JFrame frame = new JFrame("Payment Gateway");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.add(panel);

        label = new JLabel("Card Number");
        label.setBounds(10, 20, 100, 25);
        panel.add(label);

        cardDetails = new JTextField(20);
        cardDetails.setBounds(100, 20, 165, 25);
        panel.add(cardDetails);


        label2 = new JLabel("Name on card");
        label2.setBounds(10, 50, 100, 25);
        panel.add(label2);

        cardName = new JTextField(20);
        cardName.setBounds(100, 50, 165, 25);
        panel.add(cardName);

        label3 = new JLabel("CVV");
        label3.setBounds(10, 80, 100, 25);
        panel.add(label3);

        CVV = new JPasswordField();
        CVV.setBounds(100, 80, 165, 25);
        panel.add(CVV);

        btn = new JButton("Authenticate");
        btn.setBounds(80, 120, 250, 25);
        btn.addActionListener(this);
        panel.add(btn);

        success = new JLabel("");
        success.setBounds(90,160,300,25);
        panel.add(success);


        panel.setLayout(null);


        frame.setVisible(true);
    }

    public static void main(String[] args) {

        new PaymentSystem();


    }

    @Override
    public void actionPerformed(ActionEvent e) {

        success.setText("SUCCESSFUL PAYMENT");
        new EndSession();

    }
}
